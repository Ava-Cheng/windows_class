﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0426_c
{
    public partial class Form1 : Form
    {
        void displayResult_rab()
        {
            if (radioButton1.Checked) label1.Text = "男";
            else if (radioButton2.Checked) label1.Text = "女";

            if (radioButton3.Checked) label1.Text += " ,高中職以下";
            else if (radioButton4.Checked) label1.Text += " ,高中職";
            else label1.Text += " ,大專院校";
        }

        void displayResult_chb()
        {      
            if(checkBox1.Checked)label2.Text = "跑步";
            if(checkBox2.Checked)label2.Text += "、游泳";
            if(checkBox3.Checked)label2.Text += "、足球";
            if(checkBox4.Checked)label2.Text += "、籃球";

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //    label1.Text = "女";
            //
            //
            //    if (radioButton3.Checked) label1.Text += " ,高中職以下";
            //    else if (radioButton4.Checked) label1.Text += " ,高中職";
            //    else label1.Text += " ,大專院校";

            displayResult_rab(); //將上述簡化
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Text = "女";
            radioButton2.Text = "男";

            radioButton3.Text = "高中職以下";
            radioButton4.Text = "高中職";
            radioButton5.Text = "大專院校";

            radioButton2.Checked = true;
            radioButton4.Checked = true;


           checkBox1.Text = "跑步";
           checkBox2.Text = "游泳";
           checkBox3.Text = "足球";
           checkBox4.Text = "籃球";


        }

        private void button1_Click(object sender, EventArgs e)
        {
           if (radioButton1.Checked )
           {
               label1.Text = "女";
           }
           else if (radioButton2.Checked)
           {
               label1.Text = "男";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //        label1.Text = "男";
            //
            //
            //    if (radioButton3.Checked) label1.Text += " ,高中職以下";
            //    else if (radioButton4.Checked) label1.Text += " ,高中職";
            //    else label1.Text += " ,大專院校";

            displayResult_rab();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //
            //    if (radioButton1.Checked) label1.Text = "男";
            //    else if(radioButton2.Checked) label1.Text = "女";
            //    label1.Text = "高中職以下";

            displayResult_rab();

        }              
        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            //    if (radioButton1.Checked) label1.Text = "男";
            //    else if (radioButton2.Checked) label1.Text = "女";
            //    label1.Text = "高中職";


            displayResult_rab();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // if (radioButton1.Checked) label1.Text = "男";
            // else if (radioButton2.Checked) label1.Text = "女";
            // label1.Text = "大專院校";

            displayResult_rab();


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            displayResult_chb();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            displayResult_chb();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            displayResult_chb();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            displayResult_chb();
        }
    }
}
