﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p_C107118202_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int n = Convert.ToInt32(textBox1.Text);
            textBox2.Clear();
            if (n < 2 || n > 10)
            {
                MessageBox.Show("輸入錯誤,請輸入2-10之間的數字");
            }
            else {
                for (int i = 1; i <= n; i++)
                {
                    for (int k = 1; k <= n - i; k++)
                    {
                        textBox2.Text += " ";
                    }


                    for (int j = 1; j <= 2 * i - 1; j++)
                    {
                        textBox2.Text += "*";

                    }

                    //每打印完一行换一下行
                    textBox2.Text += "\r\n";
                }
            }
            

        }
    }
}
