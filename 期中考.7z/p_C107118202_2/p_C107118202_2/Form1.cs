﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p_C107118202_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(textBox1.Text);
            int n2 = Convert.ToInt32(textBox2.Text);
            int n3 = Convert.ToInt32(textBox3.Text);
            int n4 = Convert.ToInt32(textBox4.Text);
            int total_num = n1 + n2 + n3 + n4;
            int min = 0;
            int discount_num = 1;
            int total_money = n1 * 100 + n2 * 80 + n3 * 75 + n4 * 70;
            label5.Text = Convert.ToString(total_num);
            if (n1 < 0 || n2 < 0 || n3 < 0 || n4 < 0)
            {
                MessageBox.Show("輸入錯誤,麻煩您在確認一次數量");
                label5.Text = "個數顯示";
                label6.Text = "應付金額";
                label8.Text = "如果折扣才顯示";
                label10.Text = "退回金額";
                textBox1.Text = "0";
                textBox2.Text = "0";
                textBox3.Text = "0";
                textBox4.Text = "0";
                textBox5.Text = "0";
            }
            else {
                discount_num = (int)total_num / 10;
                while (discount_num > 0)
                {
                    if (n4 > 0)
                    {
                        min += 70;
                    }
                    else if (n3 > 0)
                    {
                        min += 75;
                    }
                    else if (n2 > 0)
                    {
                        min += 80;
                    }
                    else
                    {
                        min += 100;
                    }
                    discount_num -= 1;
                }

                if (total_num >= 10)
                {
                    label8.Text = Convert.ToString(total_money) + "-" + Convert.ToString(min);
                    label6.Text = Convert.ToString(total_money - min);
                }
                else
                {
                    label6.Text = Convert.ToString(total_money);
                    label8.Text = Convert.ToString(total_money) + "-0";
                }

                label10.Text = "退回金額";
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(textBox1.Text);
            int n2 = Convert.ToInt32(textBox2.Text);
            int n3 = Convert.ToInt32(textBox3.Text);
            int n4 = Convert.ToInt32(textBox4.Text);
            int client = Convert.ToInt32(textBox5.Text);
            int total_num = n1 + n2 + n3 + n4;
            int min = 0;
            int discount_num = 1;
            int total_money = n1 * 100 + n2 * 80 + n3 * 75 + n4 * 70;
            label5.Text = Convert.ToString(total_num);
            if (n1 < 0 && n2 < 0 && n3 < 0 && n4 < 0)
            {
                MessageBox.Show("輸入錯誤,麻煩您在確認一次數量");
                label5.Text = "個數顯示";
                label6.Text = "應付金額";
                label8.Text = "如果折扣才顯示";
                label10.Text = "退回金額";
                textBox1.Text = "0";
                textBox2.Text = "0";
                textBox3.Text = "0";
                textBox4.Text = "0";
                textBox5.Text = "0";
            }
            else {
                discount_num = (int)total_num / 10;
                while (discount_num > 0)
                {
                    if (n4 > 0)
                    {
                        min += 70;
                    }
                    else if (n3 > 0)
                    {
                        min += 75;
                    }
                    else if (n2 > 0)
                    {
                        min += 80;
                    }
                    else
                    {
                        min += 100;
                    }
                    discount_num -= 1;
                }

                if (total_num >= 10)
                {
                    label8.Text = Convert.ToString(total_money) + "-" + Convert.ToString(min);
                    label6.Text = Convert.ToString(total_money - min);
                }
                else
                {
                    label6.Text = Convert.ToString(total_money);
                    label8.Text = Convert.ToString(total_money) + "-0";
                }
                if ((client - Convert.ToInt32(label6.Text)) < 0)
                {
                    label10.Text = "不夠錢付款,還差" + Convert.ToString(Convert.ToInt32(label6.Text) - client) + "元";
                }
                else
                {
                    label10.Text = Convert.ToString(client - Convert.ToInt32(label6.Text));
                }

            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            label5.Text = "個數顯示";
            label6.Text = "應付金額";
            label8.Text = "如果折扣才顯示";
            label10.Text = "退回金額";
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";
        }
    }
}
